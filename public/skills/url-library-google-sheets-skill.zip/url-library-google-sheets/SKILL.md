---
name: url-library-google-sheets
description: Build a URL library Google Sheet with Search Console query × page data and GA4 sessions per page, using the free Search Analytics for Sheets and GA4 Reports Builder add-ons, then download it as .xlsx for the keyword cannibalization checker or the internal linking tool. Use when someone wants to export Search Console and GA4 data into Google Sheets, build or refresh their URL library, or prepare the upload file for either tool.
---

# Build a URL library sheet (Search Console + GA4)

The goal is one Google Sheet with two tabs, downloaded as .xlsx and uploaded to the keyword cannibalization checker or the internal linking tool (Settings → "Add your Search Console and GA4 data"):

| Tab | Columns | Source |
| --- | --- | --- |
| `Search Console` | Query, Page, Clicks, Impressions, CTR, Position | Search Analytics for Sheets add-on, grouped by Query **and** Page, last 3 months |
| `GA4` | pagePath (or landingPage), sessions | GA4 Reports Builder for Google Analytics add-on, last 365 days |

## Before you start

Ask (once, in one message) only for what you can't see:
1. The site's domain (e.g. example.com).
2. Whether they have Search Console access (ideally a domain property) and GA4 access for that site, signed in with the same Google account in their browser.
3. Whether you should click through it for them in their browser (if a browser tool such as Claude in Chrome is available) or guide them step by step.

Never ask for or type passwords, and never approve Google permission screens for the user: when an add-on asks for access, tell them which account to pick and let them click Allow.

## Steps

### 1. Create the Sheet
Open https://sheets.new and name it `URL library – <domain>`.

### 2. Search Console data
1. Extensions → Add-ons → Get add-ons → search **Search Analytics for Sheets** → Install (user approves access).
2. Extensions → Search Analytics for Sheets → Open Sidebar → **Requests** tab:
   - Verified site: the site's property (prefer `sc-domain:<domain>`)
   - Date range: last 3 months
   - Search type: Web
   - Group by: **Query** and **Page** (both)
   - Rows returned: the maximum offered (100,000; use 50,000 for very large sites if the request is slow)
   - Results sheet: new sheet, then rename the tab `Search Console`
3. Request data. Check the header row reads Query, Page, Clicks, Impressions, CTR, Position.

Do not use the Export button in the Search Console UI: it exports queries and pages separately, and the checker needs them paired.

### 3. GA4 data
1. Extensions → Add-ons → Get add-ons → search **GA4 Reports Builder for Google Analytics** (by Google) → Install.
2. Extensions → GA4 Reports Builder for Google Analytics → **Create new report**:
   - Account and property: the site's GA4 property
   - Date range: last 365 days
   - Dimensions: `pagePath` (or `landingPage`)
   - Metrics: `sessions`
   - Limit: 100000
3. Create report, then Extensions → GA4 Reports Builder → **Run reports**. Rename the output tab `GA4`. Report details above the header row are fine.

### 4. Download and upload
1. File → Download → Microsoft Excel (.xlsx).
2. In the cannibalization checker or internal linking tool: Settings → "Add your Search Console and GA4 data" → upload the file → Build the library.

## Checks before handing over
- Search Console tab has thousands of rows (a handful means Group by was not set to Query + Page, or the wrong property was picked).
- Page values are full URLs on the right domain.
- GA4 tab has page paths and a sessions column with numbers.

## Monthly refresh
Re-run both add-on requests in the same Sheet (Search Analytics for Sheets can also schedule a monthly backup), download as .xlsx again, upload, and rebuild the library.

## If something fails
- Add-on can't see the property: the signed-in Google account lacks access; switch accounts in the add-on or ask the site owner to add them in Search Console / GA4.
- Request is slow or times out: lower Rows returned, or shorten the date range to 2 months.
- The tool says the file is too big: lower Rows returned and re-download.
